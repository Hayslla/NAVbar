# NavBarExemplo
## Apenas um exemplo básico de uma Barra de Navegação utilizando HTML + CSS.

#### Vídeo no Youtube: https://youtu.be/zpErx_jt3wU
